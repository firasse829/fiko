package com.fiko.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var llm: LlmInference? = null
    private val prefs by lazy { getSharedPreferences("fiko", MODE_PRIVATE) }
    private val history = ArrayList<Pair<String, String>>()
    private val modelFile get() = File(filesDir, "model.task")
    @Volatile private var busy = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        if (modelFile.exists()) loadModel()
        else say("Fiko", "اضغط «النموذج» واختر ملف نموذج بصيغة .task (مثل Gemma).")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(24, 64, 24, 24)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }
        val bar = LinearLayout(this)
        bar.addView(TextView(this).apply {
            text = "Fiko"; textSize = 22f
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        })
        bar.addView(btn("النموذج") { pick() })
        bar.addView(btn("قواعدي") { rulesDialog() })
        bar.addView(btn("مسح") { history.clear(); log.text = "" })
        scroll = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f) }
        log = TextView(this).apply { textSize = 16f; setTextIsSelectable(true); setPadding(8, 16, 8, 16) }
        scroll.addView(log)
        val row = LinearLayout(this)
        input = EditText(this).apply {
            hint = "اكتب..."; maxLines = 4
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        row.addView(input)
        row.addView(btn("إرسال") { onSend() })
        root.addView(bar); root.addView(scroll); root.addView(row)
        setContentView(root)
    }

    private fun ui(f: () -> Unit) = runOnUiThread(f)

    private fun say(who: String, t: String) {
        log.append("$who:\n$t\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, 1)
    }

    @Deprecated("simple")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        val u = d?.data
        if (r == 1 && c == RESULT_OK && u != null) {
            say("Fiko", "جارٍ نسخ النموذج... قد يستغرق دقائق.")
            thread {
                try {
                    contentResolver.openInputStream(u)!!.use { i ->
                        modelFile.outputStream().use { o -> i.copyTo(o) }
                    }
                    ui { loadModel() }
                } catch (e: Throwable) {
                    ui { say("Fiko", "فشل النسخ: ${e.message}") }
                }
            }
        }
    }

    private fun loadModel() {
        say("Fiko", "جارٍ تحميل النموذج...")
        thread {
            try {
                val o = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath)
                    .setMaxTokens(2048)
                    .build()
                llm = LlmInference.createFromOptions(this, o)
                ui { say("Fiko", "جاهز. اكتب رسالتك، أو /search موضوع، أو /remember نص، أو /forget") }
            } catch (e: Throwable) {
                ui { say("Fiko", "تعذر تحميل النموذج: ${e.message}") }
            }
        }
    }

    private fun rulesDialog() {
        val e = EditText(this).apply {
            setText(prefs.getString("rules", "")); minLines = 6; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle("قواعدي").setView(e)
            .setPositiveButton("حفظ") { _, _ -> prefs.edit().putString("rules", e.text.toString()).apply() }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun onSend() {
        if (busy) return
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        if (t.startsWith("/remember ")) { addMem(t.substring(10).trim()); say("Fiko", "حفظت."); return }
        if (t == "/forget") { prefs.edit().putString("mem", "[]").apply(); say("Fiko", "مُسحت الذاكرة."); return }
        val m = llm
        if (m == null) { say("Fiko", "حمّل النموذج أولاً."); return }
        say("أنت", t)
        busy = true
        thread {
            try {
                var q = t
                var extra = ""
                if (t.startsWith("/search ")) {
                    q = t.substring(8).trim()
                    extra = "\n\n[نتائج بحث من الإنترنت]\n" + search(q)
                } else if (t.startsWith("تذكر")) addMem(t)
                val a = m.generateResponse(buildPrompt(q + extra, q)).trim()
                history.add(q to a)
                while (history.size > 4) history.removeAt(0)
                ui { say("Fiko", a) }
            } catch (e: Throwable) {
                ui { say("Fiko", "خطأ: ${e.message}") }
            }
            busy = false
        }
    }

    private fun buildPrompt(userText: String, q: String): String {
        var sys = (prefs.getString("rules", "") ?: "").trim()
        val rel = recall(q)
        if (rel.isNotEmpty()) sys += "\n\n[أشياء أعرفها عن المستخدم]\n" + rel.joinToString("\n") { "- $it" }
        val turns = ArrayList<Pair<String, String>>()
        for ((u, a) in history) { turns.add("user" to u); turns.add("model" to a) }
        turns.add("user" to userText)
        if (sys.isNotEmpty()) turns[0] = "user" to (sys.trim() + "\n\n" + turns[0].second)
        val sb = StringBuilder()
        for ((role, text) in turns) sb.append("<start_of_turn>$role\n$text<end_of_turn>\n")
        sb.append("<start_of_turn>model\n")
        return sb.toString()
    }

    private fun mem() = JSONArray(prefs.getString("mem", "[]"))
    private fun addMem(s: String) {
        val a = mem(); a.put(s); prefs.edit().putString("mem", a.toString()).apply()
    }
    private fun words(s: String) = Regex("\\p{L}{3,}").findAll(s.lowercase()).map { it.value }.toSet()
    private fun recall(q: String): List<String> {
        val qw = words(q); val a = mem()
        return (0 until a.length()).map { a.getString(it) }
            .map { it to words(it).intersect(qw).size }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(5).map { it.first }
    }

    private fun clean(h: String) =
        android.text.Html.fromHtml(h.replace(Regex("<.*?>"), ""), 0).toString().trim()

    private fun search(q: String): String = try {
        val c = URL("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
            .openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        c.connectTimeout = 15000; c.readTimeout = 15000
        val p = c.inputStream.bufferedReader().readText()
        val o = RegexOption.DOT_MATCHES_ALL
        val t = Regex("class=\"result__a\"[^>]*>(.*?)</a>", o).findAll(p).map { clean(it.groupValues[1]) }.toList()
        val s = Regex("class=\"result__snippet\"[^>]*>(.*?)</a>", o).findAll(p).map { clean(it.groupValues[1]) }.toList()
        t.zip(s).take(5).joinToString("\n") { "- ${it.first}: ${it.second}" }.take(2500).ifEmpty { "لا نتائج." }
    } catch (e: Throwable) { "تعذر البحث: ${e.message}" }
}
